import React from 'react';
import { Link } from 'react-router-dom';

const Index = () => {
  return <div>hi</div>;
};

export default Index;
